# Design Agent

## Quick Start

Double-click `start-design-agent.command`. The application opens in your browser. If macOS shows a security warning, navigate to the Privacy & Security settings in System Settings and scroll down to the Security and click "Open Anyway".

## Requirements

macOS

## Functionality

Component management tab: validate, upload, and view components and regulators in your own local database that was automatically created on first launch and seeded with initial data. The database file (`ltl.db`) is stored next to the executable.

